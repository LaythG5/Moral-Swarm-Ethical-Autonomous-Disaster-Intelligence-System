function [assignments, costMatrix] = assignDrones(victims, drones, config)
% ASSIGNDRONES Solves the victim-to-drone assignment problem.
%
% PURPOSE:
%   Determines which drone should rescue which victim by formulating
%   the problem as a linear assignment problem (LAP) and solving it
%   with binary integer programming (Optimization Toolbox). The cost
%   function blends travel time, battery feasibility, payload
%   suitability, and victim priority so that urgent, reachable victims
%   are matched to the most capable nearby drone.
%
% INPUTS:
%   victims - table with X, Y, PriorityScore, ResourcesRequired columns.
%   drones  - table with X, Y, Battery, Payload, Status, Speed columns.
%   config  - struct with config.assignment fields: maxDistance,
%             minBatteryReserve.
%
% OUTPUTS:
%   assignments - table, one row per victim, with columns:
%                 VictimID, DroneID (NaN if unassigned), Distance,
%                 ETA (estimated arrival time, seconds), Feasible (bool)
%   costMatrix  - [numVictims x numDrones] matrix of assignment costs
%                 (Inf where infeasible), useful for explainability.
%
% ALGORITHM:
%   1. Build a cost matrix C(i,j) = travel time of drone j to victim i,
%      penalized by battery margin and payload mismatch, and rewarded
%      (lowered) for high victim priority (so urgent victims are
%      preferentially matched to their best drone).
%   2. Mark entries infeasible (Inf) if distance exceeds maxDistance,
%      drone is not idle, or battery after the round-trip would fall
%      below minBatteryReserve.
%   3. Solve the resulting assignment problem with intlinprog as a
%      0/1 binary linear program (one drone per victim, each drone used
%      at most once -- avoids unnecessary multi-drone duplication).
%      If the Optimization Toolbox is unavailable, fall back to a
%      greedy nearest-feasible-drone heuristic.
%   4. Victims with no feasible drone remain unassigned (DroneID = NaN).

    arguments
        victims table
        drones table
        config struct
    end

    nV = height(victims);
    nD = height(drones);
    maxDist = config.assignment.maxDistance;
    minReserve = config.assignment.minBatteryReserve;

    costMatrix = inf(nV, nD);
    distMatrix = inf(nV, nD);
    etaMatrix  = inf(nV, nD);

    for i = 1:nV
        for j = 1:nD
            if ~strcmp(drones.Status{j}, 'idle')
                continue;   % busy or failed drones are not assignable
            end
            d = hypot(victims.X(i) - drones.X(j), victims.Y(i) - drones.Y(j));
            if d > maxDist
                continue;   % out of feasible range
            end
            eta = d / drones.Speed(j);                      % seconds
            batteryCost = (d * 2) / (drones.Speed(j) * 600);  % round-trip battery fraction estimate
            remainingBattery = drones.Battery(j) - batteryCost;
            if remainingBattery < minReserve
                continue;   % would violate safety reserve
            end
            payloadPenalty = max(0, victims.ResourcesRequired(i) - drones.Payload(j)) * 50;
            priorityBonus = victims.PriorityScore(i) * 10;    % lowers cost for urgent victims

            distMatrix(i,j) = d;
            etaMatrix(i,j)  = eta;
            costMatrix(i,j) = eta + payloadPenalty - priorityBonus;
        end
    end

    DroneIDAssign = nan(nV,1);
    DistanceAssign = nan(nV,1);
    ETAAssign = nan(nV,1);
    FeasibleAssign = false(nV,1);

    if any(isfinite(costMatrix(:)))
        useOptim = exist('intlinprog', 'file') == 2 || exist('intlinprog', 'builtin') == 5;
    else
        useOptim = false;
    end

    if useOptim
        try
            [rowIdx, colIdx] = solveAssignmentILP(costMatrix);
        catch ME
            warning('assignDrones:optimFallback', ...
                'intlinprog failed (%s); falling back to greedy heuristic.', ME.message);
            [rowIdx, colIdx] = greedyAssignment(costMatrix);
        end
    else
        [rowIdx, colIdx] = greedyAssignment(costMatrix);
    end

    for k = 1:numel(rowIdx)
        i = rowIdx(k); j = colIdx(k);
        if isfinite(costMatrix(i,j))
            DroneIDAssign(i) = drones.DroneID(j);
            DistanceAssign(i) = distMatrix(i,j);
            ETAAssign(i) = etaMatrix(i,j);
            FeasibleAssign(i) = true;
        end
    end

    assignments = table(victims.VictimID, DroneIDAssign, DistanceAssign, ETAAssign, FeasibleAssign, ...
        'VariableNames', {'VictimID','DroneID','Distance','ETA','Feasible'});
end

% ------------------------------------------------------------------------
function [rowIdx, colIdx] = solveAssignmentILP(costMatrix)
% SOLVEASSIGNMENTILP Solves the LAP as a 0/1 binary integer program.
% INPUTS:  costMatrix [nV x nD], Inf entries are infeasible pairs.
% OUTPUTS: rowIdx, colIdx - matched victim/drone index pairs (feasible only).
% ALGORITHM: Standard assignment-problem ILP formulation:
%   minimize sum(c_ij * x_ij)
%   s.t. sum_j x_ij <= 1  for each victim i  (each victim gets <=1 drone)
%        sum_i x_ij <= 1  for each drone j   (each drone used <=1 time)
%        x_ij = 0 for infeasible (i,j) pairs (removed from problem)
    [nV, nD] = size(costMatrix);
    feasibleMask = isfinite(costMatrix);
    [iList, jList] = find(feasibleMask);
    nVars = numel(iList);

    if nVars == 0
        rowIdx = []; colIdx = [];
        return;
    end

    f = costMatrix(sub2ind(size(costMatrix), iList, jList));

    % Victim constraints: sum_j x_ij <= 1
    Aineq1 = zeros(nV, nVars);
    for r = 1:nVars
        Aineq1(iList(r), r) = 1;
    end
    % Drone constraints: sum_i x_ij <= 1
    Aineq2 = zeros(nD, nVars);
    for r = 1:nVars
        Aineq2(jList(r), r) = 1;
    end

    Aineq = [Aineq1; Aineq2];
    bineq = ones(nV + nD, 1);

    intcon = 1:nVars;
    lb = zeros(nVars,1);
    ub = ones(nVars,1);

    opts = optimoptions('intlinprog', 'Display', 'off');
    x = intlinprog(f, intcon, Aineq, bineq, [], [], lb, ub, opts);

    if isempty(x)
        rowIdx = []; colIdx = [];
        return;
    end

    selected = round(x) == 1;
    rowIdx = iList(selected);
    colIdx = jList(selected);
end

% ------------------------------------------------------------------------
function [rowIdx, colIdx] = greedyAssignment(costMatrix)
% GREEDYASSIGNMENT Fallback heuristic when Optimization Toolbox is absent.
% INPUTS:  costMatrix [nV x nD]
% OUTPUTS: rowIdx, colIdx - matched index pairs (feasible only)
% ALGORITHM: Repeatedly pick the globally cheapest feasible (victim,drone)
%   pair, lock both out, and repeat until no feasible pairs remain.
%   Not globally optimal but a reasonable, fast approximation.
    C = costMatrix;
    [nV, nD] = size(C);
    rowIdx = []; colIdx = [];
    usedRows = false(nV,1);
    usedCols = false(nD,1);

    for k = 1:min(nV, nD)
        [minVal, linIdx] = min(C(:));
        if ~isfinite(minVal)
            break;
        end
        [i, j] = ind2sub(size(C), linIdx);
        rowIdx(end+1,1) = i; %#ok<AGROW>
        colIdx(end+1,1) = j; %#ok<AGROW>
        usedRows(i) = true;
        usedCols(j) = true;
        C(i,:) = inf;
        C(:,j) = inf;
    end
end
