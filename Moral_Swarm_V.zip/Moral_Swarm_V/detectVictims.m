function victims = detectVictims(victims, config)

    arguments
        victims table
        config struct
    end

    n = height(victims);
    detectionThreshold = 0.5;
    noiseStd = 0.03;

    confidence = betarnd(5, 1.5, n, 1);
    victims.DetectionConfidence = confidence;
    victims.Detected = confidence > detectionThreshold;

    attrCols = {'MedicalUrgency','Accessibility','EnvironmentalRisk','ResourcesRequired'};
    for c = 1:numel(attrCols)
        col = attrCols{c};
        noisy = victims.(col) + noiseStd * randn(n,1);
        noisy = min(max(noisy, 0), 1);            % clip to valid range
        victims.(col)(victims.Detected) = noisy(victims.Detected);
    end

    fprintf('      Sensor fusion: %d/%d victims detected (mean confidence %.2f)\n', ...
        sum(victims.Detected), n, mean(confidence));
end
