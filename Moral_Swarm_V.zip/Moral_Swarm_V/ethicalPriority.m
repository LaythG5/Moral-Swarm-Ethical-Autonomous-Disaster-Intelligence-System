function victims = ethicalPriority(victims, weights)

    arguments
        victims table
        weights struct
    end

    wSum = weights.medicalUrgency + weights.accessibility + ...
           weights.environmentalRisk + weights.resourcesRequired;
    if abs(wSum - 1.0) > 1e-6
        warning('ethicalPriority:weightSum', ...
            'Priority weights sum to %.3f (expected 1.0). Scores will still be computed but are not strictly normalized.', wSum);
    end

    med  = min(max(victims.MedicalUrgency, 0), 1);
    acc  = min(max(victims.Accessibility, 0), 1);
    risk = min(max(victims.EnvironmentalRisk, 0), 1);
    res  = min(max(victims.ResourcesRequired, 0), 1);

    PriorityScore = weights.medicalUrgency * med + ...
                     weights.accessibility  * acc + ...
                     weights.environmentalRisk * (1 - risk) + ...
                     weights.resourcesRequired  * (1 - res);

    victims.PriorityScore = PriorityScore;
end
