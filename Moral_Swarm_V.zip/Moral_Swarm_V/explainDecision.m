function explanations = explainDecision(victims, drones, assignments, costMatrix, config)


    arguments
        victims table
        drones table
        assignments table
        costMatrix double
        config struct
    end

    nV = height(victims);
    explanations = repmat(struct('VictimID', [], 'Decision', '', ...
        'AssignedDrone', '', 'PriorityScore', [], 'Confidence', [], ...
        'Reasoning', {{}}, 'AlternativeChoice', ''), nV, 1);

    medianPriority = median(victims.PriorityScore);
    priorityRange = max(victims.PriorityScore) - min(victims.PriorityScore);
    if priorityRange < eps, priorityRange = 1; end

    for i = 1:nV
        vID = victims.VictimID(i);
        rowMatch = assignments.VictimID == vID;
        droneID = assignments.DroneID(rowMatch);
        feasible = assignments.Feasible(rowMatch);

        reasoning = {};

        % --- Reasoning bullets from victim attributes ---
        if victims.MedicalUrgency(i) > 0.66
            reasoning{end+1} = sprintf('high medical urgency (%.2f)', victims.MedicalUrgency(i)); %#ok<AGROW>
        elseif victims.MedicalUrgency(i) > 0.33
            reasoning{end+1} = sprintf('moderate medical urgency (%.2f)', victims.MedicalUrgency(i)); %#ok<AGROW>
        else
            reasoning{end+1} = sprintf('lower medical urgency (%.2f)', victims.MedicalUrgency(i)); %#ok<AGROW>
        end

        if victims.Accessibility(i) > 0.66
            reasoning{end+1} = 'highly accessible route'; %#ok<AGROW>
        elseif victims.Accessibility(i) > 0.33
            reasoning{end+1} = 'partially accessible route'; %#ok<AGROW>
        else
            reasoning{end+1} = 'difficult / obstructed route'; %#ok<AGROW>
        end

        if victims.EnvironmentalRisk(i) < 0.33
            reasoning{end+1} = 'low environmental risk'; %#ok<AGROW>
        elseif victims.EnvironmentalRisk(i) < 0.66
            reasoning{end+1} = 'moderate environmental risk'; %#ok<AGROW>
        else
            reasoning{end+1} = 'high environmental risk'; %#ok<AGROW>
        end

        if victims.ResourcesRequired(i) < 0.33
            reasoning{end+1} = 'minimal resources required'; %#ok<AGROW>
        else
            reasoning{end+1} = sprintf('substantial resources required (%.2f)', victims.ResourcesRequired(i)); %#ok<AGROW>
        end

        % --- Decision / drone / confidence ---
        if isempty(droneID) || isnan(droneID) || ~feasible
            decision = 'No drone could be assigned';
            assignedDroneStr = 'None (no feasible drone within range/battery/payload constraints)';
            confidence = 0.0;
            altStr = 'None available';
        else
            decision = sprintf('Rescue victim %d', vID);
            assignedDroneStr = sprintf('Drone %d', droneID);

            dIdx = find(drones.DroneID == droneID, 1);
            reasoning{end+1} = sprintf('nearby available drone (Drone %d, battery %.0f%%)', ...
                droneID, drones.Battery(dIdx) * 100); %#ok<AGROW>

            % Confidence: combine priority dominance + cost-gap clarity
            priorityComponent = min(1, max(0, (victims.PriorityScore(i) - medianPriority) / priorityRange + 0.5));

            rowCosts = costMatrix(i, :);
            feasibleCosts = sort(rowCosts(isfinite(rowCosts)));
            if numel(feasibleCosts) >= 2
                gap = feasibleCosts(2) - feasibleCosts(1);
                gapComponent = min(1, gap / max(1, feasibleCosts(1) + 1));
                altDroneIdx = find(costMatrix(i,:) == feasibleCosts(2), 1);
                altStr = sprintf('Drone %d (higher cost by %.2f)', drones.DroneID(altDroneIdx), gap);
            elseif numel(feasibleCosts) == 1
                gapComponent = 0.5;  % only one feasible option; moderate confidence
                altStr = 'No other feasible drone existed';
            else
                gapComponent = 0;
                altStr = 'None available';
            end

            confidence = 0.6 * priorityComponent + 0.4 * gapComponent;
            confidence = min(max(confidence, 0), 1);
        end

        explanations(i).VictimID = vID;
        explanations(i).Decision = decision;
        explanations(i).AssignedDrone = assignedDroneStr;
        explanations(i).PriorityScore = victims.PriorityScore(i);
        explanations(i).Confidence = confidence;
        explanations(i).Reasoning = reasoning;
        explanations(i).AlternativeChoice = altStr;
    end

    % Sort explanations by priority score descending for readability
    [~, order] = sort([explanations.PriorityScore], 'descend');
    explanations = explanations(order);
end
