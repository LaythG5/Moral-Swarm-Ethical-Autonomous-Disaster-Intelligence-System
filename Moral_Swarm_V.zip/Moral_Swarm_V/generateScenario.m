function mission = generateScenario(config)


    arguments
        config struct
    end

    s = config.scenario;
    W = s.mapSize(1);
    H = s.mapSize(2);

    %  Victims 
    nV = s.numVictims;
    VictimID = (1:nV)';
    X = rand(nV,1) * W;
    Y = rand(nV,1) * H;
    MedicalUrgency    = rand(nV,1);              % 0 (stable) - 1 (critical)
    Accessibility     = rand(nV,1);               % 0 (blocked) - 1 (open route)
    EnvironmentalRisk = rand(nV,1);                % 0 (safe) - 1 (extreme hazard)
    ResourcesRequired = rand(nV,1);                % 0 (minimal) - 1 (heavy gear)
    Detected          = false(nV,1);               % set by detectVictims.m
    Rescued           = false(nV,1);               % updated during mission

    victims = table(VictimID, X, Y, MedicalUrgency, Accessibility, ...
        EnvironmentalRisk, ResourcesRequired, Detected, Rescued);

    % Drones 
    nD = s.numDrones;
    DroneID   = (1:nD)';
    X         = rand(nD,1) * W;
    Y         = rand(nD,1) * H;
    Battery   = 0.6 + rand(nD,1) * 0.4;     % 60%-100% initial charge
    Payload   = 0.5 + rand(nD,1) * 0.5;     % normalized payload capacity [0.5,1]
    Status    = repmat({'idle'}, nD, 1);     % idle | enroute | failed
    Speed     = repmat(config.assignment.speed, nD, 1) .* (0.9 + 0.2*rand(nD,1));

    drones = table(DroneID, X, Y, Battery, Payload, Status, Speed);

    % Hazards (circular zones) 
    nH = s.numHazards;
    HazardID = (1:nH)';
    X = rand(nH,1) * W;
    Y = rand(nH,1) * H;
    Radius = 3 + rand(nH,1) * 8;
    Severity = rand(nH,1);
    hazards = table(HazardID, X, Y, Radius, Severity);

    %  Collapsed buildings (rectangular footprints) 
    nC = s.numCollapsed;
    BuildingID = (1:nC)';
    X = rand(nC,1) * W;
    Y = rand(nC,1) * H;
    Width  = 4 + rand(nC,1) * 10;
    Height = 4 + rand(nC,1) * 10;
    collapsedBuildings = table(BuildingID, X, Y, Width, Height);

    % Blocked roads (line segments) 
    nR = s.numBlockedRoads;
    RoadID = (1:nR)';
    X1 = rand(nR,1) * W; Y1 = rand(nR,1) * H;
    X2 = X1 + (rand(nR,1)-0.5) * 20;
    Y2 = Y1 + (rand(nR,1)-0.5) * 20;
    blockedRoads = table(RoadID, X1, Y1, X2, Y2);

    %  Assemble mission struct 
    mission = struct();
    mission.victims = victims;
    mission.drones = drones;
    mission.hazards = hazards;
    mission.collapsedBuildings = collapsedBuildings;
    mission.blockedRoads = blockedRoads;
    mission.mapSize = s.mapSize;
end
