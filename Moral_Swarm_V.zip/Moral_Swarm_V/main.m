clear; clc; close all;
rng(42, 'twister');  
addpath(genpath(pwd));

fprintf('=============================================================\n');
fprintf(' MORAL SWARM - Ethical Autonomous Disaster Intelligence System\n');
fprintf('=============================================================\n\n');

config = struct();

config.scenario.numVictims      = 12;
config.scenario.numDrones       = 4;
config.scenario.numHazards      = 5;
config.scenario.numCollapsed    = 3;
config.scenario.numBlockedRoads = 4;
config.scenario.mapSize         = [100, 100];   % meters [x, y]

config.weights.medicalUrgency    = 0.50;
config.weights.accessibility     = 0.25;
config.weights.environmentalRisk = 0.15;   % applied as (1 - risk)
config.weights.resourcesRequired = 0.10;   % applied as (1 - resources)

% Drone assignment configuration
config.assignment.maxDistance     = 80;     % meters, hard feasibility cutoff
config.assignment.speed           = 12;     % m/s nominal drone speed
config.assignment.minBatteryReserve = 0.15; % 15% reserve required after mission

% Replanning trigger (for demonstration)
config.replan.simulateDroneFailure = true;
config.replan.simulateNewVictim    = true;

fprintf('Configuration loaded. Weights sum = %.2f\n\n', ...
    config.weights.medicalUrgency + config.weights.accessibility + ...
    config.weights.environmentalRisk + config.weights.resourcesRequired);

%% 1. SCENARIO GENERATION 
fprintf('[1/8] Generating disaster scenario...\n');
mission = generateScenario(config);
fprintf('      %d victims, %d drones, %d hazards, %d collapsed buildings, %d blocked roads\n\n', ...
    height(mission.victims), height(mission.drones), height(mission.hazards), ...
    height(mission.collapsedBuildings), height(mission.blockedRoads));

%% 2. VICTIM DETECTION
fprintf('[2/8] Running sensor fusion / victim detection...\n');
mission.victims = detectVictims(mission.victims, config);
fprintf('      Detection complete. %d victims confirmed.\n\n', height(mission.victims));

%%  3. ETHICAL PRIORITIZATION ]
fprintf('[3/8] Computing ethical priority scores...\n');
mission.victims = ethicalPriority(mission.victims, config.weights);
[~, sortIdx] = sort(mission.victims.PriorityScore, 'descend');
fprintf('      Top priority victim: #%d (score = %.3f)\n\n', ...
    mission.victims.VictimID(sortIdx(1)), mission.victims.PriorityScore(sortIdx(1)));

%%  4. DRONE ASSIGNMENT (OPTIMIZATION)
fprintf('[4/8] Solving drone-victim assignment problem...\n');
[assignments, costMatrix] = assignDrones(mission.victims, mission.drones, config);
mission.assignments = assignments;
fprintf('      %d / %d victims assigned to drones.\n\n', ...
    sum(~isnan(assignments.DroneID)), height(mission.victims));

%%  5. EXPLAINABLE AI 
fprintf('[5/8] Generating explainable AI reports...\n\n');
explanations = explainDecision(mission.victims, mission.drones, assignments, costMatrix, config);
mission.explanations = explanations;
for i = 1:min(3, numel(explanations))
    printExplanation(explanations(i));
end
if numel(explanations) > 3
    fprintf('      ... (%d more explanations generated, see mission.explanations)\n\n', ...
        numel(explanations) - 3);
end

%% 6. DYNAMIC REPLANNING 
fprintf('[6/8] Simulating disruption and dynamic replanning...\n');
[mission, replanLog] = updateMission(mission, config);
mission.replanLog = replanLog;
fprintf('      Replanning triggered by: %s\n', strjoin(replanLog.triggers, ', '));
fprintf('      %d victims re-assigned after disruption.\n\n', replanLog.numReassigned);

%% 7. PERFORMANCE METRICS
fprintf('[7/8] Computing performance metrics...\n');
metricsLog = metrics(mission, config);
mission.metrics = metricsLog;
printMetricsSummary(metricsLog);

%% 8. VISUALIZATION
fprintf('[8/8] Rendering visualization dashboard...\n');
visualization(mission, config);
fprintf('      Dashboard rendered (see figure windows).\n\n');

fprintf('=============================================================\n');
fprintf(' MORAL SWARM pipeline complete.\n');
fprintf(' Explore "mission" in the workspace for full results.\n');
fprintf('=============================================================\n');

%% LOCAL HELPER FUNCTIONS 
function printExplanation(exp)
% PURPOSE: Pretty-print a single explainable-AI decision record to console.
% INPUTS:  exp - struct produced by explainDecision.m
% OUTPUTS: none (console output only)
    fprintf('---------------------------------------------------------\n');
    fprintf('Victim %d selected:\n', exp.VictimID);
    fprintf('  Decision:          %s\n', exp.Decision);
    fprintf('  Assigned Drone:    %s\n', exp.AssignedDrone);
    fprintf('  Priority Score:    %.3f\n', exp.PriorityScore);
    fprintf('  Confidence:        %.1f%%\n', exp.Confidence * 100);
    fprintf('  Reasoning:\n');
    for k = 1:numel(exp.Reasoning)
        fprintf('    - %s\n', exp.Reasoning{k});
    end
    fprintf('  Alternative Choice: %s\n', exp.AlternativeChoice);
    fprintf('---------------------------------------------------------\n\n');
end

function printMetricsSummary(m)

    fprintf('      Average Response Time:   %.2f s\n', m.avgResponseTime);
    fprintf('      Coverage Efficiency:      %.1f%%\n', m.coverageEfficiency * 100);
    fprintf('      Mission Completion Rate:  %.1f%%\n', m.completionRate * 100);
    fprintf('      Average Rescue Priority:  %.3f\n', m.avgRescuePriority);
    fprintf('      Drone Utilization:        %.1f%%\n', m.droneUtilization * 100);
    fprintf('      Fairness Index (Jain):    %.3f\n', m.fairnessIndex);
    fprintf('      Resource Efficiency:      %.1f%%\n\n', m.resourceEfficiency * 100);
end
