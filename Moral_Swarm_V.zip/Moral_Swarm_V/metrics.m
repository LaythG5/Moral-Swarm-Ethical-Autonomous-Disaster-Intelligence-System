function m = metrics(mission, config)


    arguments
        mission struct
        config struct
    end

    victims = mission.victims;
    drones = mission.drones;
    assignments = mission.assignments;

    feasibleMask = assignments.Feasible;
    nVictims = height(victims);
    nDrones = height(drones);

    % --- Average response time (ETA) over feasible assignments ---
    if any(feasibleMask)
        m.avgResponseTime = mean(assignments.ETA(feasibleMask));
    else
        m.avgResponseTime = NaN;
    end

    % --- Coverage efficiency: fraction of victims with a feasible drone ---
    m.coverageEfficiency = sum(feasibleMask) / max(1, nVictims);

    % --- Mission completion rate: fraction marked Rescued ---
    if ismember('Rescued', victims.Properties.VariableNames)
        m.completionRate = sum(victims.Rescued) / max(1, nVictims);
    else
        m.completionRate = 0;
    end

    % --- Average rescue priority of victims that got assigned ---
    assignedVictimIDs = assignments.VictimID(feasibleMask);
    if ~isempty(assignedVictimIDs)
        [~, idx] = ismember(assignedVictimIDs, victims.VictimID);
        m.avgRescuePriority = mean(victims.PriorityScore(idx));
    else
        m.avgRescuePriority = NaN;
    end

    % --- Drone utilization: fraction of non-failed drones actually used ---
    activeDrones = sum(~strcmp(drones.Status, 'failed'));
    usedDroneIDs = unique(assignments.DroneID(feasibleMask));
    m.droneUtilization = numel(usedDroneIDs) / max(1, activeDrones);

    % --- Fairness index (Jain's index) over per-drone assigned workload ---
    workload = zeros(nDrones, 1);
    for j = 1:nDrones
        workload(j) = sum(assignments.DroneID(feasibleMask) == drones.DroneID(j));
    end
    if sum(workload) > 0
        m.fairnessIndex = (sum(workload)^2) / (nDrones * sum(workload.^2));
    else
        m.fairnessIndex = 0;
    end

    % --- Resource efficiency: payload-vs-requirement match for assigned victims ---
    if ~isempty(assignedVictimIDs)
        ratios = zeros(numel(assignedVictimIDs), 1);
        for k = 1:numel(assignedVictimIDs)
            vID = assignedVictimIDs(k);
            dID = assignments.DroneID(assignments.VictimID == vID);
            vIdx = victims.VictimID == vID;
            dIdx = drones.DroneID == dID;
            req = victims.ResourcesRequired(vIdx);
            pay = drones.Payload(dIdx);
            if pay >= req
                ratios(k) = 1 - (pay - req); % penalize over-provisioning slightly
            else
                ratios(k) = max(0, 1 - 2*(req - pay)); % penalize under-provisioning more
            end
        end
        m.resourceEfficiency = mean(max(0, min(1, ratios)));
    else
        m.resourceEfficiency = 0;
    end
end
