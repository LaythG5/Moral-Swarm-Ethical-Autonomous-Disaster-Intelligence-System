function [rowIdx, colIdx, exitInfo] = optimizeAssignments(costMatrix, solverName)

    arguments
        costMatrix double
        solverName string = "ilp"
    end

    exitInfo = struct('solver', solverName, 'success', false, 'totalCost', NaN);

    if solverName == "ilp"
        try
            [rowIdx, colIdx] = ilpAssign(costMatrix);
            exitInfo.solver = "ilp";
            exitInfo.success = true;
        catch ME
            warning('optimizeAssignments:fallback', ...
                'ILP solve failed (%s). Using greedy fallback.', ME.message);
            [rowIdx, colIdx] = greedyAssign(costMatrix);
            exitInfo.solver = "greedy";
            exitInfo.success = true;
        end
    else
        [rowIdx, colIdx] = greedyAssign(costMatrix);
        exitInfo.solver = "greedy";
        exitInfo.success = true;
    end

    if ~isempty(rowIdx)
        linIdx = sub2ind(size(costMatrix), rowIdx, colIdx);
        exitInfo.totalCost = sum(costMatrix(linIdx));
    else
        exitInfo.totalCost = 0;
    end
end

% ------------------------------------------------------------------------
function [rowIdx, colIdx] = ilpAssign(costMatrix)
% ILPASSIGN Exact binary-integer-program solution to the LAP.
% INPUTS:  costMatrix [nRows x nCols], Inf = infeasible pair.
% OUTPUTS: rowIdx, colIdx - matched pairs minimizing total feasible cost.
% ALGORITHM: standard assignment ILP (see assignDrones.m for full derivation).
    [nR, nC] = size(costMatrix);
    feasibleMask = isfinite(costMatrix);
    [iList, jList] = find(feasibleMask);
    nVars = numel(iList);

    if nVars == 0
        rowIdx = []; colIdx = [];
        return;
    end

    f = costMatrix(sub2ind(size(costMatrix), iList, jList));

    Aineq1 = zeros(nR, nVars);
    for r = 1:nVars, Aineq1(iList(r), r) = 1; end
    Aineq2 = zeros(nC, nVars);
    for r = 1:nVars, Aineq2(jList(r), r) = 1; end

    Aineq = [Aineq1; Aineq2];
    bineq = ones(nR + nC, 1);
    intcon = 1:nVars;
    lb = zeros(nVars,1); ub = ones(nVars,1);

    opts = optimoptions('intlinprog', 'Display', 'off');
    x = intlinprog(f, intcon, Aineq, bineq, [], [], lb, ub, opts);

    if isempty(x)
        rowIdx = []; colIdx = [];
        return;
    end
    selected = round(x) == 1;
    rowIdx = iList(selected);
    colIdx = jList(selected);
end

% ------------------------------------------------------------------------
function [rowIdx, colIdx] = greedyAssign(costMatrix)
% GREEDYASSIGN Fast nearest-cost greedy heuristic fallback.
% INPUTS:  costMatrix [nRows x nCols]
% OUTPUTS: rowIdx, colIdx - matched pairs (feasible only)
% ALGORITHM: iteratively select the globally minimal remaining feasible
%   cost entry, lock its row/column out, repeat.
    C = costMatrix;
    [nR, nC] = size(C);
    rowIdx = []; colIdx = [];
    for k = 1:min(nR, nC)
        [minVal, linIdx] = min(C(:));
        if ~isfinite(minVal), break; end
        [i, j] = ind2sub(size(C), linIdx);
        rowIdx(end+1,1) = i; %#ok<AGROW>
        colIdx(end+1,1) = j; %#ok<AGROW>
        C(i,:) = inf;
        C(:,j) = inf;
    end
end
