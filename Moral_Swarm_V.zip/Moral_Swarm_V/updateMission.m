function [mission, replanLog] = updateMission(mission, config)


    arguments
        mission struct
        config struct
    end

    replanLog = struct('triggers', {{}}, 'numReassigned', 0, ...
        'previousAssignments', mission.assignments);

    % ---------------- 1. Apply disruption events ----------------
    if isfield(config, 'replan') && isfield(config.replan, 'simulateDroneFailure') ...
            && config.replan.simulateDroneFailure
        idleDrones = find(strcmp(mission.drones.Status, 'idle'));
        if ~isempty(idleDrones)
            failedIdx = idleDrones(randi(numel(idleDrones)));
            mission.drones.Status{failedIdx} = 'failed';
            replanLog.triggers{end+1} = sprintf('Drone %d failure', mission.drones.DroneID(failedIdx));
        end
    end

    if isfield(config, 'replan') && isfield(config.replan, 'simulateNewVictim') ...
            && config.replan.simulateNewVictim
        newID = max(mission.victims.VictimID) + 1;
        W = mission.mapSize(1); H = mission.mapSize(2);
        newVictim = mission.victims(1, :); % template row for column structure
        newVictim.VictimID = newID;
        newVictim.X = rand() * W;
        newVictim.Y = rand() * H;
        newVictim.MedicalUrgency = 0.7 + 0.3*rand();  % newly discovered victims modeled as urgent
        newVictim.Accessibility = rand();
        newVictim.EnvironmentalRisk = rand();
        newVictim.ResourcesRequired = rand();
        newVictim.Detected = true;
        newVictim.Rescued = false;
        if ismember('DetectionConfidence', mission.victims.Properties.VariableNames)
            newVictim.DetectionConfidence = 0.9;
        end
        if ismember('PriorityScore', mission.victims.Properties.VariableNames)
            newVictim.PriorityScore = NaN; % recomputed below
        end
        mission.victims = [mission.victims; newVictim];
        replanLog.triggers{end+1} = sprintf('New victim discovered (Victim %d)', newID);
    end

    % Low-battery check: ground any drone below reserve threshold
    lowBatteryMask = mission.drones.Battery < config.assignment.minBatteryReserve ...
        & strcmp(mission.drones.Status, 'idle');
    if any(lowBatteryMask)
        groundedIDs = mission.drones.DroneID(lowBatteryMask);
        [mission.drones.Status{lowBatteryMask}] = deal('failed');
        replanLog.triggers{end+1} = sprintf('Low battery grounding: Drone(s) %s', ...
            mat2str(groundedIDs'));
    end

    if isempty(replanLog.triggers)
        replanLog.triggers{end+1} = 'No disruption occurred';
    end

    % ---------------- 2. Recompute priorities (covers new victim) -------
    mission.victims = ethicalPriority(mission.victims, weightsFromConfig(config));

    % ---------------- 3. Re-solve assignment with updated state ---------
    [newAssignments, newCostMatrix] = assignDrones(mission.victims, mission.drones, config);

    % ---------------- 4. Diff against previous plan ----------------------
    prev = replanLog.previousAssignments;
    numReassigned = 0;
    for i = 1:height(newAssignments)
        vID = newAssignments.VictimID(i);
        prevRow = prev.VictimID == vID;
        if any(prevRow)
            prevDrone = prev.DroneID(prevRow);
            newDrone = newAssignments.DroneID(i);
            if (isnan(prevDrone) ~= isnan(newDrone)) || ...
               (~isnan(prevDrone) && ~isnan(newDrone) && prevDrone ~= newDrone)
                numReassigned = numReassigned + 1;
            end
        else
            numReassigned = numReassigned + 1; % brand-new victim counts as reassigned
        end
    end
    replanLog.numReassigned = numReassigned;

    mission.assignments = newAssignments;

    % ---------------- 5. Regenerate explanations for new plan -----------
    mission.explanations = explainDecision(mission.victims, mission.drones, ...
        newAssignments, newCostMatrix, config);
end

% ------------------------------------------------------------------------
function weights = weightsFromConfig(config)
% WEIGHTSFROMCONFIG Small helper extracting the weights struct from config.
% INPUTS:  config - full pipeline config struct
% OUTPUTS: weights - struct with the four ethical priority weight fields
    weights = config.weights;
end
