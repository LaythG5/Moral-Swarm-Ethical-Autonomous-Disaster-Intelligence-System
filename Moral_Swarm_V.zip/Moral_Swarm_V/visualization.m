function visualization(mission, config)


    arguments
        mission struct
        config struct
    end

    plotMissionMap(mission);
    plotPriorityChart(mission);
    plotDronePaths(mission);
    plotMissionTimeline(mission);
    plotResourceUtilization(mission);
    plotDecisionTree(mission, config);
    plotPerformanceDashboard(mission);
end

% ========================================================================
function plotMissionMap(mission)
% PLOTMISSIONMAP Spatial overview: victims, drones, hazards, obstacles.
% INPUTS:  mission struct. OUTPUTS: none (figure).
    figure('Name', 'Mission Map', 'Color', 'w');
    hold on; axis equal;
    xlim([0 mission.mapSize(1)]); ylim([0 mission.mapSize(2)]);

    % Hazards as translucent red circles
    for h = 1:height(mission.hazards)
        viscircles([mission.hazards.X(h), mission.hazards.Y(h)], ...
            mission.hazards.Radius(h), 'Color', [1 0 0], 'LineWidth', 0.5);
    end

    % Collapsed buildings as gray rectangles
    for b = 1:height(mission.collapsedBuildings)
        rectangle('Position', [mission.collapsedBuildings.X(b) - mission.collapsedBuildings.Width(b)/2, ...
                                mission.collapsedBuildings.Y(b) - mission.collapsedBuildings.Height(b)/2, ...
                                mission.collapsedBuildings.Width(b), mission.collapsedBuildings.Height(b)], ...
                  'FaceColor', [0.5 0.5 0.5 0.6], 'EdgeColor', 'k');
    end

    % Blocked roads as dashed black lines
    for r = 1:height(mission.blockedRoads)
        plot([mission.blockedRoads.X1(r), mission.blockedRoads.X2(r)], ...
             [mission.blockedRoads.Y1(r), mission.blockedRoads.Y2(r)], ...
             'k--', 'LineWidth', 1.5);
    end

    % Victims colored by priority
    scatter(mission.victims.X, mission.victims.Y, 60, mission.victims.PriorityScore, ...
        'filled', 'MarkerEdgeColor', 'k');
    colormap(gca, 'parula');
    cb = colorbar; cb.Label.String = 'Priority Score';

    % Drones as triangle markers
    activeMask = ~strcmp(mission.drones.Status, 'failed');
    scatter(mission.drones.X(activeMask), mission.drones.Y(activeMask), 120, '^', ...
        'MarkerFaceColor', [0 0.6 0], 'MarkerEdgeColor', 'k');
    scatter(mission.drones.X(~activeMask), mission.drones.Y(~activeMask), 120, '^', ...
        'MarkerFaceColor', [0.6 0 0], 'MarkerEdgeColor', 'k');

    legend({'Victims (color = priority)', 'Active Drones', 'Failed Drones'}, ...
        'Location', 'bestoutside');
    title('Mission Map: Victims, Drones, Hazards & Obstacles');
    xlabel('X (m)'); ylabel('Y (m)');
    hold off;
end

% ========================================================================
function plotPriorityChart(mission)
% PLOTPRIORITYCHART Bar chart of victim priority scores, sorted descending.
% INPUTS:  mission struct. OUTPUTS: none (figure).
    figure('Name', 'Victim Priority Chart', 'Color', 'w');
    [sortedScores, idx] = sort(mission.victims.PriorityScore, 'descend');
    labels = "V" + string(mission.victims.VictimID(idx));
    bar(sortedScores, 'FaceColor', [0.2 0.4 0.8]);
    set(gca, 'XTick', 1:numel(sortedScores), 'XTickLabel', labels, 'XTickLabelRotation', 45);
    ylabel('Priority Score');
    title('Victim Priority Ranking');
    grid on;
end

% ========================================================================
function plotDronePaths(mission)
% PLOTDRONEPATHS Shows each drone's path to its assigned victim.
% INPUTS:  mission struct. OUTPUTS: none (figure).
    figure('Name', 'Drone Paths', 'Color', 'w');
    hold on; axis equal;
    xlim([0 mission.mapSize(1)]); ylim([0 mission.mapSize(2)]);

    colors = lines(height(mission.drones));
    for i = 1:height(mission.assignments)
        if ~mission.assignments.Feasible(i), continue; end
        vID = mission.assignments.VictimID(i);
        dID = mission.assignments.DroneID(i);
        vRow = mission.victims.VictimID == vID;
        dRow = mission.drones.DroneID == dID;
        plot([mission.drones.X(dRow), mission.victims.X(vRow)], ...
             [mission.drones.Y(dRow), mission.victims.Y(vRow)], ...
             '-', 'Color', colors(dID, :), 'LineWidth', 1.8);
        scatter(mission.drones.X(dRow), mission.drones.Y(dRow), 100, '^', ...
            'MarkerFaceColor', colors(dID,:), 'MarkerEdgeColor', 'k');
        scatter(mission.victims.X(vRow), mission.victims.Y(vRow), 70, 'o', ...
            'MarkerFaceColor', colors(dID,:), 'MarkerEdgeColor', 'k');
    end
    title('Drone Paths to Assigned Victims');
    xlabel('X (m)'); ylabel('Y (m)');
    hold off;
end

% ========================================================================
function plotMissionTimeline(mission)
% PLOTMISSIONTIMELINE Horizontal bar timeline of estimated arrival times.
% INPUTS:  mission struct. OUTPUTS: none (figure).
    figure('Name', 'Mission Timeline', 'Color', 'w');
    feasibleMask = mission.assignments.Feasible;
    etas = mission.assignments.ETA(feasibleMask);
    vIDs = mission.assignments.VictimID(feasibleMask);
    [sortedEtas, idx] = sort(etas);
    barh(sortedEtas, 'FaceColor', [0.85 0.5 0.1]);
    set(gca, 'YTick', 1:numel(sortedEtas), 'YTickLabel', "V" + string(vIDs(idx)));
    xlabel('Estimated Time of Arrival (s)');
    title('Mission Timeline: Rescue ETAs');
    grid on;
end

% ========================================================================
function plotResourceUtilization(mission)
% PLOTRESOURCEUTILIZATION Bar chart of each drone's battery and payload use.
% INPUTS:  mission struct. OUTPUTS: none (figure).
    figure('Name', 'Resource Utilization', 'Color', 'w');
    nD = height(mission.drones);
    workload = zeros(nD, 1);
    for j = 1:nD
        workload(j) = sum(mission.assignments.DroneID(mission.assignments.Feasible) == mission.drones.DroneID(j));
    end
    yyaxis left;
    bar(mission.drones.DroneID, mission.drones.Battery * 100, 'FaceColor', [0.3 0.7 0.3]);
    ylabel('Battery Remaining (%)');
    yyaxis right;
    plot(mission.drones.DroneID, workload, '-o', 'LineWidth', 2, 'Color', [0.7 0.1 0.1]);
    ylabel('Victims Assigned');
    xlabel('Drone ID');
    title('Drone Resource Utilization');
    grid on;
end

% ========================================================================
function plotDecisionTree(mission, config)
% PLOTDECISIONTREE Simplified visual summary of the ethical scoring logic.
% INPUTS:  mission struct, config struct. OUTPUTS: none (figure).
% NOTE: This is a schematic decision-tree-style diagram of the scoring
%       formula and thresholds used in ethicalPriority.m / explainDecision.m,
%       not a trained classifier tree (the engine is a transparent
%       weighted-sum model by design, for auditability).
    figure('Name', 'Decision Tree (Scoring Logic)', 'Color', 'w');
    axis off;
    title('Ethical Priority Decision Logic (schematic)');

    w = config.weights;
    text(0.5, 0.95, 'PriorityScore = w_1*Medical + w_2*Access + w_3*(1-Risk) + w_4*(1-Resources)', ...
        'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 10);

    labels = {sprintf('Medical Urgency (w=%.2f)', w.medicalUrgency), ...
              sprintf('Accessibility (w=%.2f)', w.accessibility), ...
              sprintf('Environmental Risk (w=%.2f, inverted)', w.environmentalRisk), ...
              sprintf('Resources Required (w=%.2f, inverted)', w.resourcesRequired)};

    yPos = linspace(0.75, 0.35, numel(labels));
    for i = 1:numel(labels)
        rectangle('Position', [0.25, yPos(i)-0.05, 0.5, 0.08], 'Curvature', 0.2, ...
            'FaceColor', [0.85 0.9 1]);
        text(0.5, yPos(i)-0.01, labels{i}, 'HorizontalAlignment', 'center', 'FontSize', 9);
        annotation('arrow', [0.5 0.5], [0.92 yPos(i)+0.04]);
    end

    rectangle('Position', [0.3, 0.08, 0.4, 0.1], 'Curvature', 0.3, 'FaceColor', [1 0.9 0.7]);
    text(0.5, 0.13, 'Ranked Priority -> Drone Assignment (ILP)', ...
        'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 9);
    annotation('arrow', [0.5 0.5], [0.30 0.19]);
end

% ========================================================================
function plotPerformanceDashboard(mission)
% PLOTPERFORMANCEDASHBOARD Summary panel of all key performance metrics.
% INPUTS:  mission struct (must contain .metrics). OUTPUTS: none (figure).
    if ~isfield(mission, 'metrics')
        return;
    end
    m = mission.metrics;
    figure('Name', 'Performance Dashboard', 'Color', 'w');

    names = {'Coverage Eff.', 'Completion Rate', 'Drone Util.', ...
             'Fairness Idx', 'Resource Eff.'};
    values = [m.coverageEfficiency, m.completionRate, m.droneUtilization, ...
              m.fairnessIndex, m.resourceEfficiency] * 100;

    bar(values, 'FaceColor', [0.25 0.5 0.75]);
    set(gca, 'XTickLabel', names, 'XTickLabelRotation', 20);
    ylabel('Percent / Index (%)');
    ylim([0 110]);
    title(sprintf('Performance Dashboard  |  Avg Response Time: %.1fs  |  Avg Priority: %.2f', ...
        m.avgResponseTime, m.avgRescuePriority));
    grid on;
    for i = 1:numel(values)
        text(i, values(i) + 3, sprintf('%.1f', values(i)), 'HorizontalAlignment', 'center');
    end
end
